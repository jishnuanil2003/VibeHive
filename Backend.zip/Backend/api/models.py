from django.db import models

# Create your models here
class Booking(models.Model):
    name = models.CharField(max_length=100)
    email = models.EmailField()
    location = models.CharField(max_length=100)
    check_in = models.DateField()
    check_out = models.DateField()
    people = models.PositiveIntegerField(max_length=1)

    def __str__(self):
        return self.name