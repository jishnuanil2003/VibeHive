from rest_framework import serializers
from .models import Booking

class BookingSerializer(serializers.ModelSerializer):
    location = serializers.ChoiceField(choices=[
        ("Munnar", "Munnar"),
        ("Trivandrum", "Trivandrum"),
        ("Fort Kochi", "Fort Kochi"),
    ])
    # HTML date input widgets in the browsable API
    check_in = serializers.DateField(style={"input_type": "date"})
    check_out = serializers.DateField(style={"input_type": "date"})

    class Meta:
        model = Booking
        fields = "__all__"