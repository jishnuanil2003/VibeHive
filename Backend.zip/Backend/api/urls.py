from django.urls import path
from .views import BookingsView
urlpatterns = [
    path('Bookings/',BookingsView.as_view(), name='bookings')
]
